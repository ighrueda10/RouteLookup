#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "io.h"
#include "utils.h"
#include <sys/time.h>
#include <time.h>

struct node {
  char* prefix_in_binary;
  int puerto;
  int prof;
  struct node* hijo_izd;
  struct node* hijo_der;
};

struct arbol {
  struct node* top;
};

struct node* create_node(char* prefix_bin, int puerto) {
  struct node* new_node = (struct node*)malloc(sizeof(struct node));
  if (new_node == NULL) {
    fprintf(stderr, "Error al asignar memoria para el nodo!\n");
    exit(1);
  }

  new_node->prefix_in_binary = malloc(strlen(prefix_bin) + 1);
  if (new_node->prefix_in_binary == NULL) {
    fprintf(stderr, "Error al asignar memoria para el prefijo!\n");
    exit(1);
  }
  strcpy(new_node->prefix_in_binary, prefix_bin);

  new_node->puerto = puerto;
  new_node->prof = strlen(prefix_bin);

  new_node->hijo_izd = NULL;
  new_node->hijo_der = NULL;

  return new_node;
}

struct node* create_node_v(int puerto,int prof, char* pref_v) {
  struct node* new_node = (struct node*)malloc(sizeof(struct node));
  if (new_node == NULL) {
    fprintf(stderr, "Error al asignar memoria para el nodo!\n");
    exit(1);
  }

  new_node->prefix_in_binary = malloc(strlen(pref_v) + 1);
  if (new_node->prefix_in_binary == NULL) {
    fprintf(stderr, "Error al asignar memoria para el prefijo!\n");
    exit(1);
  }
  strcpy(new_node->prefix_in_binary, pref_v);

  new_node->puerto = puerto;
  new_node->prof = prof;

  new_node->hijo_izd = NULL;
  new_node->hijo_der = NULL;	

  return new_node;
}


int numNtrie = 0;

void insert(struct node* nodo, struct node** raiz, int index, char* pref_v) {
  if (index == nodo->prof) {
    *raiz = nodo;
	numNtrie++;
    return;
  }

  if (*raiz == NULL) {
    *raiz = create_node_v( 0, index, pref_v);
	numNtrie++;
  }

char* pref_v2 = malloc(strlen(nodo->prefix_in_binary) + 1);

  strcpy( pref_v2, (*raiz)->prefix_in_binary);

  if (nodo->prefix_in_binary[index] == '0') {
	strcat(pref_v2, "0"); // Concatenamos "0" a c
    insert(nodo, &((*raiz)->hijo_izd), index + 1, pref_v2);
	free(pref_v2);
  } else {
	strcat(pref_v2, "1"); // Concatenamos "0" a c
    insert(nodo, &((*raiz)->hijo_der), index + 1,pref_v2);
	free(pref_v2);
  }
}



int caso_compr(struct node* nodo){
    if(nodo == NULL) return 0;
    if(nodo->puerto == 0){ //Si nodo está vacío
        if(nodo->hijo_izd != NULL && nodo->hijo_der == NULL){
            return 1;
        }
        if(nodo->hijo_der != NULL && nodo->hijo_izd == NULL){
            return 2;
        }
    }
  
    
        return 3;
    
}


void actualizar_prof(struct node** nodo){
	
	 if (*nodo == NULL) {
        return;
    }
	
	(*nodo)->prof = ((*nodo)->prof)-1;
	
	actualizar_prof(&((*nodo)->hijo_izd));
	actualizar_prof(&((*nodo)->hijo_der));
	
}




void comprimir(struct node** nodo) {
    if (*nodo == NULL) {
        return;
    }

    int caso = caso_compr(*nodo);

    if(caso == 1){ //Nodo vacío, hijo_izd vacío y existe hijo_der
        struct node * aux = (*nodo)->hijo_izd;
        free((*nodo)->prefix_in_binary);
		free(*nodo);
        *nodo = aux;
		numNtrie--;
		actualizar_prof(nodo);
        comprimir(nodo);
    }

    if(caso == 2) {//Nodo vacío, hijo_der vacío y existe hijo_izd
        struct node * aux = (*nodo)->hijo_der;
        free((*nodo)->prefix_in_binary);
	   free(*nodo);
        *nodo = aux;
		numNtrie--;
		actualizar_prof(nodo);
        comprimir(nodo);
    }

    if(caso == 3) { //No hay que comprimir -  vamos a los hijos
        comprimir(&((*nodo)->hijo_izd));
        comprimir(&((*nodo)->hijo_der));
    }
}

void show_trie(struct node* nodo, int depth, char* side) {
  if (nodo == NULL) {
    return;
  }

 
  printf(" Nodo: %s, Puerto: %d, prof: %d, Lado: %s\n", nodo->prefix_in_binary, nodo->puerto, nodo->prof, side);

  show_trie(nodo->hijo_izd, depth + 1, "izquierdo");
  show_trie(nodo->hijo_der, depth + 1, "derecho");
}



int numPkpr = 0;


struct node* search(char* dir, struct node* raiz, int* numNacc) {
    struct node* current = raiz;
    struct node* last_match = NULL;

    for (int i = 0; i < strlen(dir); i++) {
       
	   if (current == NULL) {
            break;
        }

        // Si el nodo actual tiene un puerto asignado y coincide con la dirección hasta este punto,
        // lo consideramos una coincidencia
       if (current->puerto != 0 && strncmp(current->prefix_in_binary, dir, strlen(current->prefix_in_binary)) == 0) {
            last_match = current;
			*numNacc = last_match->prof;
        }

        // Avanzamos al siguiente nodo dependiendo del bit actual en la dirección
        if (dir[i+(strlen(current->prefix_in_binary)-current->prof)] == '0') {
            current = current->hijo_izd;
        } else {
            current = current->hijo_der;
        }
    }

    // Si encontramos una coincidencia, la devolvemos. Si no, devolvemos NULL.
	numPkpr++;
	if(last_match!=NULL) {
    	return last_match;
	}
	else {
		struct node *nulo = create_node("-1",0);
		return nulo;
	}
}



void bitsToArray(uint32_t num, int numBits, char array[]) {
    // Iteramos sobre los primeros X bits empezando desde la izquierda
    for (int i = 0; i < numBits; i++) {
        // Creamos una máscara para extraer el bit en la posición i
        uint32_t mask = 1 << (31 - i);
        // Extraemos el bit utilizando la máscara
        char bit = (num & mask) ? '1' : '0';
        // Almacenamos el bit en el array
        array[i] = bit;
    }
    // Agregamos el carácter nulo al final del array
    array[numBits] = '\0';
}

char* intToBinary(int num) {
    int bitSize = sizeof(num) * 8; // Calcula el tamaño en bits del número
    char* binary = malloc(bitSize + 1); // Reserva espacio para la cadena binaria

    for(int i = bitSize - 1; i >= 0; i--) {
        int bit = (num >> i) & 1; // Desplaza el bit i-ésimo a la posición más baja y lo enmascara con 1
        binary[bitSize - 1 - i] = bit + '0'; // Guarda el bit en la cadena
    }

    binary[bitSize] = '\0'; // Añade el carácter nulo al final de la cadena

    return binary;
}

void free_tree(struct node* nodo) {
    if (nodo == NULL) {
        return;
    }

    // Libera los hijos del nodo
    free_tree(nodo->hijo_izd);
    free_tree(nodo->hijo_der);

    // Libera el prefijo en binario del nodo
    free(nodo->prefix_in_binary);

    // Libera el nodo
    free(nodo);
}

int main (int argc, char**argv) {
	int status;
	

	   if(argc!=3){
	printf("Error en el nº de parámetros");
	return(-1);
	}

	uint32_t prefix;
    int prefixLength, outInterface;

	struct arbol* trie = (struct arbol*)malloc(sizeof(struct arbol));
	trie->top = NULL;	

    status = initializeIO(argv[1],argv[2]);

    if (status != OK) {
        printIOExplanationError(status);
        return -1;
    }

	while(readFIBLine(&prefix, &prefixLength, &outInterface) != REACHED_EOF) {
		
		char pref_c[prefixLength];
		bitsToArray(prefix,prefixLength,pref_c);
		printf("Prefijo en binario: %s\n", pref_c);
		struct node* nodo = create_node(pref_c, outInterface);
		insert(nodo,&(trie->top),0,"");
	}
		
	
	printf("\n\n");
	printf("Árbol sin comprimir:");
		printf("\n");
	show_trie(trie->top, 0, "raíz");
	comprimir(&(trie->top));
	printf("\n\n");
	printf("Árbol comprimido:");
		printf("\n");
	show_trie(trie->top, 0, "raíz");
	printf("\n\n");
	
	uint32_t IP_address;
	
	int naccT=0;
	int searchingTime_t=0;

	while(readInputPacketFileLine(&IP_address) != REACHED_EOF){
		double searchingTime;		
		char* binIP = intToBinary(IP_address);
		printf("Dirección binaria a buscar: %s", binIP);
		int nacc=0;
		struct timespec initialTime;
		clock_gettime(CLOCK_MONOTONIC_RAW, &initialTime);
		struct node* prueba1 = search(binIP, trie->top,&nacc);
		struct timespec finalTime;
		clock_gettime(CLOCK_MONOTONIC_RAW, &finalTime);
		printOutputLine(IP_address,prueba1->puerto,&initialTime,&finalTime,&searchingTime, nacc);
		searchingTime_t = searchingTime_t + searchingTime;

		naccT = naccT + nacc;
		printf("\n");
		printf("Puerto: %d, nodos accedidos:%d\n",prueba1->puerto,nacc);
		free(binIP);
		
		if(strcmp(prueba1->prefix_in_binary, "-1")==0){
		free(prueba1->prefix_in_binary);
		free(prueba1);
		}
	}
	
	double searchingTime_t_d=0.0;
	double naccT_d=0.0;
	 
	 naccT_d = (double)naccT;
	double nAccmd = naccT_d/numPkpr;
	 searchingTime_t_d = (double) searchingTime_t;
	double sTm = searchingTime_t_d/numPkpr;
	
	printf("Número de nodos en el árbol: %d \n", numNtrie); 
	printf("Número de paquetes procesados: %d \n", numPkpr); 
	printf("Número medio de accesos: %f \n", nAccmd); 
	printf("Número medio de tiempo de acceso: %f \n", sTm); 
	
	
	printSummary(numNtrie, numPkpr, nAccmd, sTm);
	freeIO();
	free_tree(trie->top);
	free(trie);
	
return 0;
}

